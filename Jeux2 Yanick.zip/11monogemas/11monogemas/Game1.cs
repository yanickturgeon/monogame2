﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Threading;

namespace _11monogemas
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        new Rectangle Window;
        GameObject hero;
        GameObject[] ennemi = new GameObject[3];
        GameObject proj;
        Texture2D BackgroundTexture;
        Random rng = new Random();
        int Nbennemi = 0;
        bool Victoire = false;
        SpriteFont Text;
        SoundEffect songRekt;
        SoundEffect songFuck;
        SoundEffectInstance Rekt;
        SoundEffectInstance Fuck;


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            this.graphics.PreferredBackBufferHeight = graphics.GraphicsDevice.DisplayMode.Height;
            this.graphics.PreferredBackBufferWidth = graphics.GraphicsDevice.DisplayMode.Width;
            this.graphics.ToggleFullScreen();
            Window = new Rectangle(0, 0, graphics.GraphicsDevice.DisplayMode.Width, graphics.GraphicsDevice.DisplayMode.Height);
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            //Background
            BackgroundTexture = Content.Load<Texture2D>("Backgroundtexture.jpg");
            //ennemi
            for (int i = ennemi.Length - 1; i >= 0; i--)
            {
                ennemi[i] = new GameObject();
                ennemi[i].estVivant = false;
                ennemi[i].position.X = Window.Right - 250;
                ennemi[i].position.Y = Window.Center.Y;
                ennemi[i].vitesse.X = rng.Next(-13, -7);
                ennemi[i].vitesse.Y = rng.Next(-10, 9);
                ennemi[i].sprite = Content.Load<Texture2D>("ennemi.png");
            }
            //Hero
            hero = new GameObject();
            hero.estVivant = true;
            hero.position.X = Window.Left;
            hero.position.Y = Window.Center.Y;
            hero.sprite = Content.Load<Texture2D>("hero.png");
            //proj
            proj = new GameObject();
            proj.estVivant = false;
            proj.position.X = hero.position.X + 100;
            proj.position.Y = hero.position.Y + 50;
            proj.vitesse.X = 50;
            proj.sprite = Content.Load<Texture2D>("proj.png");
            //Texte   
            Text = Content.Load<SpriteFont>("Font");
            //Son
            songRekt = Content.Load<SoundEffect>("Song\\rekt");
            Rekt = songRekt.CreateInstance();
            songFuck = Content.Load<SoundEffect>("Song\\fuck");
            Fuck = songFuck.CreateInstance();
            Song song = Content.Load<Song>("Song\\mix");
            MediaPlayer.IsRepeating = true;
            MediaPlayer.Volume = 0.05F;
            MediaPlayer.Play(song);
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            //End Game defeat
            if (hero.estVivant == false)
            {
                MediaPlayer.Stop();
                Fuck.Play();
                Thread.Sleep(2000);
                this.Exit();
            }
            //End Game victoire
            if (!ennemi[0].estVivant && !ennemi[1].estVivant && !ennemi[2].estVivant && hero.estVivant && gameTime.TotalGameTime.Seconds >= 3)
            {
                MediaPlayer.Stop();
                Rekt.Play();
                Thread.Sleep(2000);
                this.Exit();
            }
            //if (Mage.estVivant == true)
            //spawn enemy
            for (int i = ennemi.Length - 1; i >= 0; i--)
            {
                if (Nbennemi * 1 < gameTime.TotalGameTime.Seconds && Nbennemi < ennemi.Length)
                {
                    ennemi[Nbennemi].estVivant = true;
                    Nbennemi++;
                }
            }
            //déplacement
            if (Keyboard.GetState().IsKeyDown(Keys.A))
            {
                hero.vitesse.X -= 1;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.D))
            {
                hero.vitesse.X += 1;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.W))
            {
                hero.vitesse.Y -= 1;
            }
            if (Keyboard.GetState().IsKeyDown(Keys.S))
            {
                hero.vitesse.Y += 1;
            }
            //limite de map
            if (hero.position.X + 125 >= Window.Right)
            {
                hero.vitesse.X = 0;
                hero.position.X = Window.Right - 126;
            }
            if (hero.position.X <= Window.Left)
            {
                hero.vitesse.X = 0;
                hero.position.X = Window.Left + 1;
            }
            if (hero.position.Y + 150 >= Window.Bottom)
            {
                hero.vitesse.Y = 0;
                hero.position.Y = Window.Bottom - 151;
            }
            if (hero.position.Y <= Window.Top)
            {
                hero.vitesse.Y = 0;
                hero.position.Y = Window.Top + 1;
            }
            //limite de map enemy
            for (int i = ennemi.Length - 1; i >= 0; i--)
            {
                if (ennemi[i].position.Y <= Window.Top)
                {
                    ennemi[i].vitesse.Y = rng.Next(5, 10);
                }
                if (ennemi[i].position.Y >= Window.Bottom - 175)
                {
                    ennemi[i].vitesse.Y = rng.Next(-11, -6);
                }
                if (ennemi[i].position.X <= Window.Left)
                {
                    ennemi[i].vitesse.X = rng.Next(5, 10);
                }
                if (ennemi[i].position.X >= Window.Right - 175)
                {
                    ennemi[i].vitesse.X = rng.Next(-11, -6);
                }
            }
            //hero attaque
            if (hero.estVivant == true && Keyboard.GetState().IsKeyDown(Keys.Space) && proj.estVivant == false)
            {
                proj.estVivant = true;
                proj.position.X = hero.position.X + 75;
                proj.position.Y = hero.position.Y - 40;
            }
            if (proj.position.X >= Window.Right)
            {
                proj.estVivant = false;
            }
            //Collision et mort des ennemies
            for (int i = ennemi.Length - 1; i >= 0; i--)
            {
                if (this.proj.GetRekt().Intersects(this.ennemi[i].GetRekt()) && ennemi[i].estVivant == true)
                {
                    ennemi[i].estVivant = false;
                    proj.estVivant = false;
                    Rekt.Play();
                }
            }
            //Colision Mage Enemy
            for (int i = ennemi.Length - 1; i >= 0; i--)
            {
                if (hero.estVivant == true && ennemi[i].estVivant == true)
                {
                    if (this.hero.GetRekt().Intersects(this.ennemi[i].GetRekt()))
                    {
                        hero.estVivant = false;
                        Rekt.Play();
                    }
                }
            }


            // TODO: Add your update logic here
            base.Update(gameTime);
            UpdateMage();
            UpdateEnemy();
            UpdateSort();
        }
        public void UpdateMage()
        {
            hero.position += hero.vitesse;
        }
        public void UpdateEnemy()
        {
            for (int i = ennemi.Length - 1; i >= 0; i--)
            {
                ennemi[i].position += ennemi[i].vitesse;
            }
        }
        public void UpdateSort()
        {
            proj.position += proj.vitesse;
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            // TODO: Add your drawing code here
            spriteBatch.Begin();
            //Background
            spriteBatch.Draw(BackgroundTexture, new Rectangle(0, 0, graphics.GraphicsDevice.DisplayMode.Width, graphics.GraphicsDevice.DisplayMode.Height), Color.White);
            //Enemy              
            for (int i = 0; i <= 2; i++)
            {
                if (ennemi[i].estVivant == true)
                {
                    spriteBatch.Draw(ennemi[i].sprite, ennemi[i].position);
                }
            }

            //Mage
            if (hero.estVivant == true)
            {
                spriteBatch.Draw(hero.sprite, hero.position);
            }
            if (hero.estVivant == true && proj.estVivant == true)
            {
                spriteBatch.Draw(proj.sprite, proj.position);
            }
            //Text
            spriteBatch.DrawString(Text, gameTime.TotalGameTime.TotalSeconds.ToString(), new Vector2(50, 50), Color.Black);
            if (hero.estVivant == false)
            {
                spriteBatch.DrawString(Text, "GAME OVER", new Vector2(880, 540), Color.Black);
                    }
            if (!ennemi[0].estVivant && !ennemi[1].estVivant && !ennemi[2].estVivant && hero.estVivant && gameTime.TotalGameTime.Seconds >= 3)
            {
                spriteBatch.DrawString(Text, gameTime.TotalGameTime.TotalSeconds.ToString(), new Vector2(825, 370), Color.Black);
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
